Can you run part 1 task2 with this command
g++ cipher.cpp -o cipher -lcrypto -ldl -std=c++11
